<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Wavo_Page_Title extends Widget_Base {

    public function get_name() {
        return 'wavo-page-title';
    }

    public function get_title() {
        return __( 'Page Title', 'wavo' );
    }

    public function get_icon() {
        return 'eicon-heading';
    }

    public function get_keywords() {
        return [ 'woocommerce', 'woo','title','heading','wc', 'shop', 'store', 'text', 'description', 'category', 'product', 'archive' ];
    }

    public function get_categories() {
        return [ 'wavo' ];
    }

    protected function register_controls() {

        $this->start_controls_section('section_product_title_style',
            [
            'label' => __( 'Style', 'wavo' ),
            'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control( 'custom_title',
            [
                'label' => esc_html__( 'Custom Title', 'wavo' ),
                'type' => Controls_Manager::TEXT,
                'default' => ''
            ]
        );
        $this->add_control( 'tag',
            [
                'label' => esc_html__( 'Title Tag for SEO', 'wavo' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'h1',
                'options' => [
                    'h1' => esc_html__( 'H1', 'wavo' ),
                    'h2' => esc_html__( 'H2', 'wavo' ),
                    'h3' => esc_html__( 'H3', 'wavo' ),
                    'h4' => esc_html__( 'H4', 'wavo' ),
                    'h5' => esc_html__( 'H5', 'wavo' ),
                    'h6' => esc_html__( 'H6', 'wavo' ),
                    'div' => esc_html__( 'div', 'wavo' ),
                    'p' => esc_html__( 'p', 'wavo' )
                ]
            ]
        );
        $this->add_responsive_control( 'text_align',
            [
                'label' => __( 'Alignment', 'wavo' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'wavo' ),
                        'icon' => 'eicon-text-align-left'
                    ],
                    'center' => [
                        'title' => __( 'Center', 'wavo' ),
                        'icon' => 'eicon-text-align-center'
                    ],
                    'right' => [
                        'title' => __( 'Right', 'wavo' ),
                        'icon' => 'eicon-text-align-right'
                    ],
                    'justify' => [
                        'title' => __( 'Justified', 'wavo' ),
                        'icon' => 'eicon-text-align-justify'
                    ]
                ],
                'selectors' => ['{{WRAPPER}} .wavo-page-title' => 'text-align: {{VALUE}}']
            ]
        );
        $this->add_control(
            'text_color',
            [
                'label' => __( 'Text Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wavo-page-title' => 'color: {{VALUE}}' ]
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'text_typography',
                'label' => __( 'Typography', 'wavo' ),
                'selector' => '{{WRAPPER}} .wavo-page-title'
            ]
        );
        $this->add_control( 'spacing',
            [
                'label' => esc_html__( 'Bottom Spacing', 'wavo' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 300
                    ]
                ],
                'selectors' => ['{{WRAPPER}} .wavo-page-title' => 'margin-bottom: {{SIZE}}px;'],
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        global $post;
        $post_type = get_post_type( $post->ID );
        if ( $post_type == 'elementor_library' ) {
            $title = $settings['custom_title'] ? '' : get_the_title();
            echo '<'.$settings['tag'].' class="wavo-page-title">'.$title.'</'.$settings['tag'].'>';
        } else {
            if ( is_404() ) {
                $title = $settings['custom_title'] ? '' : esc_html__( 'Page Not Found', 'wavo' );
                echo '<'.$settings['tag'].' class="wavo-page-title">'.$title.'</'.$settings['tag'].'>';
            } elseif ( is_archive() ) {
                $title = $settings['custom_title'] ? '' : get_the_archive_title();
                echo '<'.$settings['tag'].' class="wavo-page-title">'.$title.'</'.$settings['tag'].'>';
            } elseif ( is_search() ) {
                echo '<'.$settings['tag'].' class="wavo-page-title">'.strlen( get_search_query() ) > 16 ? substr( get_search_query(), 0, 16 ).'...' : get_search_query().'</'.$settings['tag'].'>';
            } elseif ( is_home() || is_front_page() ) {
                $title = $settings['custom_title'] ? '' : get_bloginfo( 'name' );
                echo '<'.$settings['tag'].' class="wavo-page-title">'.$title.'</'.$settings['tag'].'>';
            } else {
                $title = $settings['custom_title'] ? '' : get_the_title();
                echo '<'.$settings['tag'].' class="wavo-page-title">'.$title.'</'.$settings['tag'].'>';
            }
        }
    }
}
