<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Wavo_Gallery_Slider extends Widget_Base {
    use Wavo_Helper;
    public function get_name() {
        return 'wavo-gallery-slider';
    }
    public function get_title() {
        return 'Gallery Slider (N)';
    }
    public function get_icon() {
        return 'eicon-slider-push';
    }
    public function get_categories() {
        return [ 'wavo-cpt' ];
    }
    public function get_style_depends() {
        return [ 'wavo-swiper' ];
    }
    public function get_script_depends() {
        return [ 'wavo-swiper','wavo-addons-custom-scripts' ];
    }
    // Registering Controls
    protected function register_controls() {
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'gallery_slider_settings',
            [
                'label' => esc_html__( 'Slider Items', 'wavo' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $def_image = plugins_url( 'assets/front/img/bg4.jpg', __DIR__ );
        $repeater = new Repeater();
        $repeater->add_control( 'image',
            [
                'label' => esc_html__( 'Image', 'wavo' ),
                'type' => Controls_Manager::MEDIA,
                'default' => ['url' => $def_image]
            ]
        );
        $repeater->add_control( 'video',
            [
                'label' => esc_html__( 'Hosted Video URL', 'wavo' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => ''
            ]
        );
        $repeater->add_control( 'video_type',
            [
                'label' => esc_html__( 'Video Size', 'wavo' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => 'true',
                'default' => 'fit',
                'options' => [
                    'default' => esc_html__( 'Default', 'wavo' ),
                    'fit' => esc_html__( 'Fit', 'wavo' ),
                ],
                'condition' => ['video!' => '']
            ]
        );
        $repeater->add_control( 'duration',
            [
                'label' => esc_html__( 'Slide Item Duration (ms)', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 50000,
                'step' => 100,
                'default' => '',
                'separator' => 'before'
            ]
        );
        $repeater->add_control( 'subtitle',
            [
                'label' => esc_html__( 'Subtitle', 'wavo' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Subtitle',
                'pleaceholder' => esc_html__( 'Enter title here', 'wavo' ),
            ]
        );
        $repeater->add_control( 'title',
            [
                'label' => esc_html__( 'Title', 'wavo' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => 'Slider Title',
                'pleaceholder' => esc_html__( 'Enter title here', 'wavo' ),
            ]
        );
        $repeater->add_control( 'desc',
            [
                'label' => esc_html__( 'Short Description', 'wavo' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => ''
            ]
        );
        $repeater->add_control( 'btn_title',
            [
                'label' => esc_html__( 'Button Title', 'wavo' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Shop Now',
                'pleaceholder' => esc_html__( 'Enter button title here', 'wavo' ),
                'separator' => 'before',
            ]
        );
        $repeater->add_control( 'btn_link',
            [
                'label' => esc_html__( 'Button Link', 'wavo' ),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'default' => [
                    'url' => '#0',
                    'is_external' => 'true'
                ],
                'placeholder' => esc_html__( 'Place URL here', 'wavo' )
            ]
        );
        $this->add_control( 'slides',
            [
                'label' => esc_html__( 'Slide Items', 'wavo' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{title}}',
                'separator' => 'before',
                'default' => [
                    [
                        'image' => ['url' => $def_image],
                        'title' => 'From Inside Out',
                        'btn_title' => 'Discover Work',
                        'btn_link' => '#0'
                    ],
                    [
                        'image' => ['url' => $def_image],
                        'title' => 'Luxury Estate',
                        'btn_title' => 'Discover Work',
                        'btn_link' => '#0'
                    ],
                    [
                        'image' => ['url' => $def_image],
                        'title' => 'Classic Modern',
                        'btn_title' => 'Discover Work',
                        'btn_link' => '#0'
                    ],
                    [
                        'image' => ['url' => $def_image],
                        'title' => 'Explore The World',
                        'btn_title' => 'Discover Work',
                        'btn_link' => '#0'
                    ]
                ]
            ]
        );
        $this->add_control( 'type',
            [
                'label' => esc_html__( 'Type', 'wavo' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => 'true',
                'default' => '1',
                'options' => [
                    '1' => esc_html__( 'Type 1', 'wavo' ),
                    '2' => esc_html__( 'Type 2', 'wavo' ),
                ]
            ]
        );
        $this->add_control( 'linktype',
            [
                'label' => esc_html__( 'Link Action', 'wavo' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => 'true',
                'default' => 'permalink',
                'options' => [
                    'permalink' => esc_html__( 'Custom link', 'wavo' ),
                    'lightbox' => esc_html__( 'Open Lightbox', 'wavo' ),
                ]
            ]
        );
        $this->add_control( 'lthumbnail_separator',
            [
                'label' => esc_html__( 'Lightbox Image Size', 'wavo' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => ['linktype' => 'lightbox']
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'lthumbnail',
                'default' => 'full',
                'condition' => ['linktype' => 'lightbox']
            ]
        );
        $this->add_responsive_control( 'slider_height',
            [
                'label' => esc_html__( 'Item Min Height', 'wavo' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'vh' ],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 2000,
                        'step' => 100
                    ],
                    'vh' => [
                        'min' => 0,
                        'max' => 100
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .work-carousel .content .img' => 'min-height: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .work-carousel .swiper-slide .bg-img' => 'min-height: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .slider-portfolio .swiper-slide .bg-img' => 'min-height: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};margin-top:0;',
                    '{{WRAPPER}} .slider-portfolio .swiper-slide' => 'min-height: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};'
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
            'name' => 'thumbnail',
            'default' => 'large'
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/

        /*****   END CONTROLS SECTION   ******/
        $this->start_controls_section( 'projects_slider_section',
            [
                'label' => esc_html__( 'Slider Options', 'wavo' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'perview',
            [
                'label' => esc_html__( 'Per View', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 2
            ]
        );
        $this->add_control( 'mdperview',
            [
                'label' => esc_html__( 'Per View 1024px', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 2
            ]
        );
        $this->add_control( 'smperview',
            [
                'label' => esc_html__( 'Per View 768px', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 2
            ]
        );
        $this->add_control( 'xsperview',
            [
                'label' => esc_html__( 'Per View 480px', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 1
            ]
        );
        $this->add_control( 'speed',
            [
                'label' => esc_html__( 'Speed', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 5000,
                'step' => 100,
                'default' => 1000,
                'separator' => 'before'
            ]
        );
        $this->add_control( 'autoplay',
            [
                'label' => esc_html__( 'Autoplay', 'wavo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'
            ]
        );
        $this->add_control( 'loop',
            [
                'label' => esc_html__( 'Loop', 'wavo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'
            ]
        );
        $this->add_control( 'nav',
            [
                'label' => esc_html__( 'Navigation', 'wavo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'
            ]
        );
        $this->add_control( 'progress',
            [
                'label' => esc_html__( 'Progress bar', 'wavo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'
            ]
        );
        $this->add_responsive_control( 'projects_slider_progressbar_top_offset',
            [
                'label' => esc_html__( 'Progressbar Top Spacing', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 200,
                'step' => 1,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-progressbar' => 'bottom:0;',
                    '{{WRAPPER}} .swiper-container' => 'padding-bottom:{{SIZE}}px;',
                ],
                'condition' => ['progress' => 'yes']
            ]
        );
        $this->add_control( 'space',
            [
                'label' => esc_html__( 'Custom Space Between Items', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .work-carousel .swiper-slide' => 'padding: 0 {{VALUE}}px;',
                    '{{WRAPPER}} .slider-portfolio .swiper-slide' => 'margin-right: {{VALUE}}px;'
                ]
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/

        /*****   END CONTROLS SECTION   ******/
        $this->start_controls_section( 'projects_slider_image_style_section',
            [
                'label' => esc_html__( 'Image Box Style', 'wavo' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->wavo_style_border( 'projects_slider_image_border', '{{WRAPPER}} .swiper-slide .bg-img,{{WRAPPER}} .swiper-slide .content.type-2' );
        $this->wavo_style_padding( 'projects_slider_image_padding', '{{WRAPPER}} .swiper-slide .bg-img,{{WRAPPER}} .swiper-slide .content.type-2' );

        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/

        /*****   END CONTROLS SECTION   ******/
        $this->start_controls_section( 'projects_slider_heading_style_section',
            [
                'label' => esc_html__( 'Text Style', 'wavo' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_responsive_control( 'projects_post_text_alignment',
            [
                'label' => esc_html__( 'Alignment', 'wavo' ),
                'type' => Controls_Manager::CHOOSE,
                'selectors' => ['{{WRAPPER}} .work-carousel .content .cont,{{WRAPPER}} .slider-portfolio .swiper-slide .caption' => 'text-align: {{VALUE}};width:100%;left:0;padding:0 40px;'],
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'wavo' ),
                        'icon' => 'eicon-h-align-left'
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'wavo' ),
                        'icon' => 'eicon-h-align-center'
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'wavo' ),
                        'icon' => 'eicon-h-align-right'
                    ]
                ],
                'toggle' => true,
                'default' => ''
            ]
        );
        $this->add_responsive_control( 'pag_padding',
            [
                'label' => esc_html__( 'Text Content Padding', 'wavo' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px' ],
                'selectors' => ['{{WRAPPER}} .work-carousel .content .cont,{{WRAPPER}} .slider-portfolio .swiper-slide .caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']
            ]
        );
        $this->add_control( 'projects_post_text_btn_color',
            [
                'label' => esc_html__( 'Button Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .caption a.dis' => 'color:{{VALUE}};',
                    '{{WRAPPER}} .caption a.dis:after' => 'background-color:{{VALUE}};'
                ],
                'condition' => ['type' => '1']
            ]
        );
        $this->add_control( 'projects_post_text_hvr_color',
            [
                'label' => esc_html__( 'Link Hover Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .work-carousel .content .cont .projects-post-title a:hover,
                    {{WRAPPER}} .work-carousel .content .cont .projects-post-cats a:hover,
                    {{WRAPPER}} .caption a.dis:hover,
                    {{WRAPPER}} [data-overlay-dark] a:hover,
                    {{WRAPPER}} [data-overlay-dark] a:hover span' => 'color:{{VALUE}};',
                    '{{WRAPPER}} .caption a.dis:hover:after' => 'background-color:{{VALUE}};'
                ]
            ]
        );
        $this->add_control( 'projects_post_title_heading',
            [
                'label' => esc_html__( 'TITLE', 'wavo' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control( 'tag',
            [
                'label' => esc_html__( 'Title Tag ( for SEO )', 'wavo' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'h4',
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'div' => 'div'
                ]
            ]
        );
        $this->wavo_style_color( 'projects_post_title_color', '{{WRAPPER}} .work-carousel .content .cont .projects-post-title,{{WRAPPER}} .caption .projects-post-title,{{WRAPPER}} [data-overlay-dark] span' );
        $this->wavo_style_typo( 'projects_post_title_typo', '{{WRAPPER}} .work-carousel .content .cont .projects-post-title,{{WRAPPER}} .caption .projects-post-title,{{WRAPPER}} [data-overlay-dark] span' );

        $this->add_control( 'projects_post_cats_heading',
            [
                'label' => esc_html__( 'SUBTITLE', 'wavo' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->wavo_style_color( 'projects_post_cats_color', '{{WRAPPER}} .work-carousel .content .cont .projects-post-cats' );
        $this->wavo_style_typo( 'projects_post_cats_typo', '{{WRAPPER}} .work-carousel .content .cont .projects-post-cats' );

        $this->add_control( 'projects_post_desc_heading',
            [
                'label' => esc_html__( 'DESCRIPTION', 'wavo' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->wavo_style_color( 'projects_post_desc_color', '{{WRAPPER}} .work-carousel .content .cont .projects-post-description' );
        $this->wavo_style_typo( 'projects_post_desc_typo', '{{WRAPPER}} .work-carousel .content .cont .projects-post-description' );

        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/

        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section('projects_slider_nav_style_section',
            [
                'label'=> esc_html__( 'Nav Style', 'wavo' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'nav_type',
            [
                'label' => esc_html__( 'Type', 'wavo' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'type_1' => 'Type 1',
                    'type_2' => 'Type 2'
                ],
                'default' => 'type_1',
            ]
        );
        $this->start_controls_tabs( 'projects_slider_nav_tabs');
        $this->start_controls_tab( 'projects_slider_nav_normal_tab',
            [ 'label'  => esc_html__( 'Normal', 'wavo' ) ]
        );

        $this->wavo_style_bgcolor( 'projects_slider_nav_background','{{WRAPPER}} .work-carousel .swiper-button-next, {{WRAPPER}} .work-carousel .swiper-button-prev' );
        $this->wavo_style_color( 'projects_slider_color','{{WRAPPER}} .work-carousel .swiper-button-next, {{WRAPPER}} .work-carousel .swiper-button-prev' );
        $this->wavo_style_border( 'projects_slider_border','{{WRAPPER}} .work-carousel .swiper-button-next, {{WRAPPER}} .work-carousel .swiper-button-prev' );
        $this->end_controls_tab();

        $this->start_controls_tab( 'projects_slider_nav_hover_tab',
            [ 'label' => esc_html__( 'Hover', 'wavo' ) ]
        );

        $this->wavo_style_bgcolor( 'projects_slider_nav_hvr_background','{{WRAPPER}} .work-carousel .swiper-button-next:hover, {{WRAPPER}} .work-carousel .swiper-button-prev:hover' );
        $this->wavo_style_color( 'projects_slider_hvr_color','{{WRAPPER}} .work-carousel .swiper-button-next:hover, {{WRAPPER}} .work-carousel .swiper-button-prev:hover' );
        $this->wavo_style_border( 'projects_slider_hvr_border','{{WRAPPER}} .work-carousel .swiper-button-next:hover, {{WRAPPER}} .work-carousel .swiper-button-prev:hover' );
        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_control( 'projects_slider_prev_heading',
            [
                'label' => esc_html__( 'PREV POSITION', 'wavo' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control( 'projects_slider_prev_horizontal',
            [
                'label' => esc_html__( 'Horizontal Position ( % )', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .work-carousel .swiper-button-prev' => 'left:{{SIZE}}%;' ],
            ]
        );
        $this->add_responsive_control( 'projects_slider_prev_vertical',
            [
                'label' => esc_html__( 'Vertical Position ( % )', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .work-carousel .swiper-button-prev' => 'top:{{SIZE}}%;' ],
            ]
        );
        $this->add_control( 'projects_slider_next_heading',
            [
                'label' => esc_html__( 'NEXT POSITION', 'wavo' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control( 'projects_slider_next_horizontal',
            [
                'label' => esc_html__( 'Horizontal Position ( % )', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .work-carousel .swiper-button-next' => 'left:{{SIZE}}%;' ],
            ]
        );
        $this->add_responsive_control( 'projects_slider_next_vertical',
            [
                'label' => esc_html__( 'Vertical Position ( % )', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .work-carousel .swiper-button-next' => 'top:{{SIZE}}%;' ],
            ]
        );
        $this->add_control( 'projects_slider_progressbar_color',
            [
                'label' => esc_html__( 'Progressbar Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .work-carousel .swiper-pagination-progressbar .swiper-pagination-progressbar-fill' => 'background-color:{{VALUE}};' ],
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control( 'projects_slider_progresbar_height',
            [
                'label' => esc_html__( 'Progressbar Height', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .work-carousel .swiper-container-horizontal>.swiper-pagination-progressbar' => 'height:{{SIZE}}px;' ],
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $settingsid = $this->get_id();

        $size = $settings['thumbnail_size'] ? $settings['thumbnail_size'] : 'full';
        if ( 'custom' == $size ) {
            $sizew = $settings['thumbnail_custom_dimension']['width'];
            $sizeh = $settings['thumbnail_custom_dimension']['height'];
            $size  = [ $sizew, $sizeh, true ];
        }
        if ( 'lightbox' == $settings['linktype'] ) {
            $lsize = $settings['lthumbnail_size'] ? $settings['lthumbnail_size'] : 'full';
            if ( 'custom' == $lsize ) {
                $lsizew = $settings['lthumbnail_custom_dimension']['width'];
                $lsizeh = $settings['lthumbnail_custom_dimension']['height'];
                $lsize  = [ $lsizew, $lsizeh, true ];
            }
        }

        $speed     = $settings['speed'] ? $settings['speed'] : 1000;
        $perview   = $settings['perview'] ? $settings['perview'] : 3;
        $mdperview = $settings['mdperview'] ? $settings['mdperview'] : 3;
        $smperview = $settings['smperview'] ? $settings['smperview'] : 2;
        $xsperview = $settings['xsperview'] ? $settings['xsperview'] : 2;
        $space     = $settings['space'] ? $settings['space'] : 30;
        $autoplay  = 'yes' == $settings['autoplay'] ? 'true' : 'false';
        $loop      = 'yes' == $settings['loop'] ? 'true' : 'false';
        $progress  = 'yes' == $settings['progress'] ? 'true' : 'false';
        $nav       = 'yes' == $settings['nav'] ? 'true' : 'false';

        $nav_icon1 = 'type_2' == $settings['nav_type'] ? '<i class="fas fa-caret-right"></i>' : '<i class="ion-ios-arrow-right"></i>';
        $nav_icon2 = 'type_2' == $settings['nav_type'] ? '<i class="fas fa-caret-left"></i>' : '<i class="ion-ios-arrow-left"></i>';

        if ( '1' == $settings['type'] ) {

            echo '<div class="slider-portfolio slider-scroll slide-controls thm-post-slider custom-project-slider" data-slider-settings=\'{"space": '.$space.',"nav":'.$nav.',"progress":'.$progress.',"autoplay":'.$autoplay.',"loop":'.$loop.',"speed":'.$speed.',"perview":'.$perview.',"mdperview":'.$mdperview.',"smperview":'.$smperview.',"xsperview":'.$xsperview.'}\'>';
                echo '<div class="swiper-container">';
                    echo '<div class="swiper-wrapper">';

                        foreach ( $settings['slides'] as $item ) {
                            if ( !empty( $item['image']['id'] ) ) {
                                $imageid    = $item['image']['id'];
                                $image_url  = wp_get_attachment_image_url( $imageid, $size );
                                $target     = !empty( $item['btn_link']['is_external'] ) ? ' target="_blank"' : '';
                                $nofollow   = !empty( $item['btn_link']['nofollow'] ) ? ' rel="nofollow"' : '';
                                $bgimg      = !empty($item['video']) ? '' : ' style="background-image:url('.$image_url.')"';
                                $delay      = 'yes' == $settings['autoplay'] && !empty($item['duration']) ? ' data-swiper-autoplay="'.$item['duration'].'"' : '';
                                $has_video  = !empty($item['video']) ? ' has-video' : '';
                                echo '<div class="swiper-slide'.$has_video.'"'.$delay.'>';
                                    echo '<div class="bg-img valign"'.$bgimg.' data-overlay-dark="3">';
                                        if ( !empty($item['video']) ) {
                                            echo '<video class="bg-video size-'.$item['video_type'].'" muted><source src="'.$item['video'].'" type="video/mp4"></video>';
                                        }
                                        if ( 'lightbox' == $settings['linktype'] ) {
                                            $image_full = wp_get_attachment_image_url( $imageid, $lsize );
                                            echo '<a class="open-lightbox" href="'.$image_full.'" title="'.$item['title'].'"></a>';
                                        }
                                        echo '<div class="caption">';
                                            if ( empty( $item['btn_link']['url'] ) ) {
                                                echo '<'.$settings['tag'].' class="projects-post-title" data-splitting>'.$item['title'].'</'.$settings['tag'].'>';
                                            } else {
                                                echo '<'.$settings['tag'].' class="projects-post-title" data-splitting><a href="'.$item['btn_link']['url'].'"'.$target.$nofollow.'>'.$item['title'].'</a></'.$settings['tag'].'>';
                                            }
                                            if ( !empty( $item['btn_title'] ) ) {
                                                echo '<a href="'.$item['btn_link']['url'].'" class="dis">'.$item['btn_title'].'</a>';
                                            }
                                        echo '</div>';
                                    echo '</div>';
                                echo '</div>';
                            }
                        }

                    echo '</div>';

                    if ( 'yes' == $settings['nav'] ) {
                        echo '<div class="swiper-button-next swiper-nav-ctrl next-ctrl t'.$settings['nav_type'].'"><i class="fas fa-caret-right"></i></div>
                        <div class="swiper-button-prev swiper-nav-ctrl prev-ctrl t'.$settings['nav_type'].'"><i class="fas fa-caret-left"></i></div>';
                    }
                    if ( 'yes' == $settings['progress'] ) {
                        echo '<div class="swiper-pagination"></div>';
                    }
                echo '</div>';
            echo '</div>';

        } else {

            $slidecontrols = 'type_2' == $settings['nav_type'] ? ' slide-controls' : '';
            echo '<div class="work-carousel thm-post-slider custom-project-slider metro'.$slidecontrols.'" data-slider-settings=\'{"nav":'.$nav.',"progress":'.$progress.',"autoplay":'.$autoplay.',"loop":'.$loop.',"speed":'.$speed.',"perview":'.$perview.',"mdperview":'.$mdperview.',"smperview":'.$smperview.',"xsperview":'.$xsperview.'}\'>';
                echo '<div class="swiper-container">';
                    echo '<div class="swiper-wrapper">';

                        foreach ( $settings['slides'] as $item ) {
                            if ( !empty( $item['image']['id'] ) ) {
                                $target     = $item['btn_link']['is_external'] ? ' target="_blank"' : '';
                                $nofollow   = $item['btn_link']['nofollow'] ? ' rel="nofollow"' : '';
                                $imageid    = $item['image']['id'];
                                $image_url  = wp_get_attachment_image_url( $imageid, $size );
                                $delay      = 'yes' == $settings['autoplay'] && !empty($item['duration']) ? ' data-swiper-autoplay="'.$item['duration'].'"' : '';
                                $has_video  = !empty($item['video']) ? ' has-video' : '';

                                echo '<div class="swiper-slide'.$has_video.'"'.$delay.'>';
                                    echo '<div class="content type-2">';
                                        if ( 'lightbox' == $settings['linktype'] ) {
                                            $image_full = wp_get_attachment_image_url( $imageid, $lsize );
                                            echo '<a class="open-lightbox" href="'.$image_full.'" title="'.$item['title'].'"></a>';
                                        }
                                        if ( !empty($item['video']) ) {
                                            echo '<div class="img"><video class="bg-video size-'.$item['video_type'].'" muted><source src="'.$item['video'].'" type="video/mp4"></video></div>';
                                        } else {
                                            echo '<div class="img">';
                                                echo '<div class="bg-img" style="background-image: url('.$image_url.')"></div>';
                                            echo '</div>';
                                        }
                                        echo '<div class="cont">';
                                            if ( !empty( $item['subtitle'] ) ) {
                                                echo '<h6 class="projects-post-cats">'.$item['subtitle'].'</h6>';
                                            }
                                            if ( !empty( $item['title'] ) ) {
                                                if ( empty( $item['btn_link']['url'] ) ) {
                                                    echo '<'.$settings['tag'].' class="projects-post-title">'.$item['title'].'</'.$settings['tag'].'>';
                                                } else {
                                                    echo '<'.$settings['tag'].' class="projects-post-title"><a href="'.$item['btn_link']['url'].'" title="'.$item['title'].'">'.$item['title'].'</a></'.$settings['tag'].'>';
                                                }
                                            }
                                            if ( !empty( $item['desc'] ) ) {
                                                echo '<p class="projects-post-desc">'.$item['desc'].'</p>';
                                            }
                                        echo '</div>';
                                    echo '</div>';
                                echo '</div>';
                            }
                        }

                    echo '</div>';

                    if ( 'yes' == $settings['nav'] ) {
                        echo '<div class="swiper-button-next swiper-nav-ctrl next-ctrl '.$settings['nav_type'].'">'.$nav_icon1.'</div>
                        <div class="swiper-button-prev swiper-nav-ctrl prev-ctrl '.$settings['nav_type'].'">'.$nav_icon2.'</div>';
                    }
                    if ( 'yes' == $settings['progress'] ) {
                        echo '<div class="swiper-pagination"></div>';
                    }

                echo '</div>
            </div>';
        }
        if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
            ?>
            <script>
                jQuery(document).ready( function ($) {
                    if ( $('.open-lightbox').length ) {
                        $('.open-lightbox').magnificPopup({
                          type: 'image',
                          gallery:{
                            enabled:true
                          }
                        });
                    }
                });
            </script>
            <?php
        }
        wp_reset_postdata();
    }
}
