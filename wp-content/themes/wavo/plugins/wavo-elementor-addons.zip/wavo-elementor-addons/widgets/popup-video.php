<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Wavo_Popup_Video extends Widget_Base {
    use Wavo_Helper;
    public function get_name() {
        return 'wavo-popup-video';
    }
    public function get_title() {
        return 'Popup Video (N)';
    }
    public function get_icon() {
        return 'eicon-youtube';
    }
    public function get_categories() {
        return [ 'wavo' ];
    }
    public function get_style_depends() {
        return [ 'youtube-popup','magnific-popup' ];
    }
    public function get_script_depends() {
        return [ 'youtube-popup','magnific-popup','wavo-addons-custom-scripts' ];
    }
    // Registering Controls
    protected function register_controls() {
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'wavo_popup_video_settings',
            [
                'label' => esc_html__('Popup Video', 'wavo'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control( 'use_local_video',
            [
                'label' => esc_html__( 'Use Hosted Video', 'wavo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no'
            ]
        );
        $this->add_control( 'video',
            [
                'label' => esc_html__( 'URL', 'wavo' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => 'https://vimeo.com/127203262',
                'label_block' => true
            ]
        );
        $this->add_control( 'muted',
            [
                'label' => esc_html__( 'Muted', 'wavo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'condition' => ['use_local_video' => 'yes']
            ]
        );
        $this->add_control( 'controls',
            [
                'label' => esc_html__( 'Controls', 'wavo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => ['use_local_video' => 'yes']
            ]
        );
        $this->add_control( 'video_width',
            [
                'label' => esc_html__( 'Width', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'condition' => ['use_local_video' => 'yes']
            ]
        );
        $this->add_control( 'video_height',
            [
                'label' => esc_html__( 'Height', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'condition' => ['use_local_video' => 'yes']
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section( 'wavo_popup_icon_style',
            [
                'label' => esc_html__( 'Icon', 'wavo' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_responsive_control( 'wavo_popup_icon_alignment',
            [
                'label' => esc_html__( 'Alignment', 'wavo' ),
                'type' => Controls_Manager::CHOOSE,
                'selectors' => ['{{WRAPPER}} .popup-video-wrapper' => 'text-align: {{VALUE}};'],
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'wavo' ),
                        'icon' => 'eicon-h-align-left'
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'wavo' ),
                        'icon' => 'eicon-h-align-center'
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'wavo' ),
                        'icon' => 'eicon-h-align-right'
                    ]
                ],
                'toggle' => true,
                'default' => ''
            ]
        );
        $this->add_responsive_control( 'wavo_popup_icon_size',
            [
                'label' => esc_html__( 'Size', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .popup-video .vid-btn .icon' => 'width:{{SIZE}}px;height:{{SIZE}}px;' ],
            ]
        );
        $this->add_control( 'projects_popup_icon_color',
            [
                'label' => esc_html__( 'Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .popup-video .vid-btn .icon' => 'color:{{VALUE}};' ],
            ]
        );
        $this->add_control( 'projects_popup_icon_brd_color',
            [
                'label' => esc_html__( 'Border Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .popup-video .vid-btn .icon' => 'color:{{VALUE}};' ],
                'separator' => 'before',
            ]
        );
        $this->add_control( 'projects_popup_icon_outline_color',
            [
                'label' => esc_html__( 'Outline Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .popup-video .vid-btn .icon:after' => 'border-color:{{VALUE}};' ],
                'separator' => 'before',
            ]
        );
        $this->add_control( 'projects_popup_icon_hvrbg_color',
            [
                'label' => esc_html__( 'Hover Background Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .popup-video .vid-btn .icon:before' => 'border-color:{{VALUE}};' ],
                'separator' => 'before',
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $id = $this->get_id();


        if ( $settings['video'] ) {

            if ( 'yes' == $settings['use_local_video'] ) {
                $vattr  = $settings['video_width'] ? ' width="'.$settings['video_width'].'"' : '';
                $vattr .= $settings['video_height'] ? ' height="'.$settings['video_height'].'"' : '';
                $vattr .= 'yes' == $settings['controls'] ? ' controls' : '';
                $vattr .= 'yes' == $settings['muted'] ? ' muted' : '';

                echo '<div class="popup-video-wrapper video-'.$id.'">';
                    echo '<a class="popup-video local-video" href="#video-'.$id.'">';
                        echo '<div class="vid-btn">';
                            echo '<span class="icon"><i class="fas fa-play"></i></span>';
                        echo '</div>';
                    echo '</a>';

                    echo '<div id="video-'.$id.'" class="video-popup mfp-hide">';
                        echo '<video'.$vattr.'>';
                            echo '<source src="'.$settings['video'].'" type="video/mp4">';
                        echo '</video>';
                    echo '</div>';
                echo '</div>';

                if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) { ?>
                    <script>
                    jQuery( document ).ready( function($) {

                        $('.video-<?php echo $id ?> .popup-video').magnificPopup({
                            type: 'inline',
                            mainClass: 'wavo-inline-video',
                            callbacks: {
                                open: function() {
                                    $('html').css('margin-right', 0);
                                    $(this.content).find('video')[0].play();
                                },
                                close: function() {
                                    $(this.content).find('video')[0].load();
                                }
                            }
                        });
                    });
                    </script>
                    <?php
                }

            } else {
                echo '<div class="popup-video-wrapper video-'.$id.'">';
                    echo '<a class="popup-video" href="'.$settings['video'].'">';
                        echo '<div class="vid-btn">';
                            echo '<span class="icon"><i class="fas fa-play"></i></span>';
                        echo '</div>';
                    echo '</a>';
                echo '</div>';
                if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) { ?>
                    <script>
                    jQuery( document ).ready( function($) {
                        $('.video-<?php echo $id ?> .popup-video').YouTubePopUp();
                    });
                    </script>
                    <?php
                }
            }
        }
    }
}
