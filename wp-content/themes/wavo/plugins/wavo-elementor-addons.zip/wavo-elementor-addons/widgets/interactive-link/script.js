!(function ($) {

    'use strict';

    function interactiveLinkSlider($Scope, $){

        var myData = $Scope.find('.interactive-link-slider-wrapper').data('slider-settings'),
            galleryTop = $Scope.find('.gallery-top'),
            galleryThumbs = $Scope.find('.gallery-thumbs'),
            next = $Scope.find('.next-ctrl'),
            prev = $Scope.find('.prev-ctrl');

        $('.bg-img[data-slide-video]').each( function(){
            console.log(typeof $('.bg-img').data('slide-video'));
            var html_video,
                start_end,
                video = $( this ).data('slide-video'),
                videoCont = $( this ).find('.slide-video-container'),
                provider = video.provider,
                start = video.start ? 'start='+video.start+'&' : '',
                end = video.end ? 'end='+video.end+'&' : '',
                videoid = video.video_id;

            if ( videoid.length ) {

                if ( 'vimeo' == provider ) {
                    html_video = '<iframe class="elementor-background-embed-video vimeo-video" title="vimeo Video Player" src="https://player.vimeo.com/video/'+videoid+'?'+start+end+'autoplay=1&loop=1&autopause=0&mute=1&showinfo=0" allow="autoplay; fullscreen" webkitallowfullscreen mozallowfullscreen allowfullscreen frameborder="0" data-ready="true" width="640" height="360"></iframe>';
                }

                if ( 'youtube' == provider ) {
                    html_video = '<iframe class="elementor-background-embed-video youtube-video" title="youtube Video Player" src="https://www.youtube.com/embed/'+videoid+'?'+start+end+'controls=0&rel=0&autoplay=1&playsinline=1&enablejsapi=1&version=3&playerapiid=ytplayer&mute=1" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" webkitallowfullscreen mozallowfullscreen allowfullscreen frameborder="0" width="640" height="360"></iframe>';
                }
                if ( 'hosted' == provider ) {
                    start_end = ( start && end ) ? '#t='+video.start+','+video.start : '';
                    html_video = '<video class="elementor-background-video-hosted elementor-html5-video video-hosted" autoplay mute playsinline loop src="'+videoid+start_end+'"></video>';
                }
                videoCont.prepend( html_video );
            }
        });

        var myThumbs = new SwiperNT(galleryThumbs[0], {
            slidesPerView: 1,
            speed: myData.speed,
            loop: false,
            mousewheel: myData.mousewheel,
            //autoplay: myData.autoplay,
            spaceBetween: 0,
            observer: true,
            freeMode: false,
            watchSlidesVisibility: true,
            watchSlidesProgress: true,
            updateOnWindowResize: true,
            simulateTouch: false,
            grabCursor: false,
            slideToClickedSlide: true,
            on: {
                init: function() {

                    var activeSlide = galleryThumbs.find('.swiper-slide.swiper-slide-active'),
                        inactiveSlide = galleryThumbs.find('.swiper-slide:not(.swiper-slide-active)');

                    if ( $(window).width() > 1024 ) {
                        inactiveSlide.find('.slide-item-footer').slideUp();
                        activeSlide.find('.slide-item-footer').slideDown();

                    } else {
                        galleryThumbs.find('.slide-item-footer').slideDown();
                    }
                },
                slideChange: function () {

                },
                resize: function() {
                    var swiper = this;
                    swiper.update();
                }
            },
            breakpoints: {
                320: {
                    slidesPerView: myData.smperview
                },
                768: {
                    slidesPerView: myData.mdperview
                },
                1024: {
                    slidesPerView: myData.perview
                }
            }
        });
        var mySwiper = new SwiperNT(galleryTop[0], {
            spaceBetween: 0,
            speed: myData.speed,
            loop: false,
            mousewheel: myData.mousewheel,
            autoplay: myData.autoplay,
            parallax: myData.parallax,
            watchSlidesVisibility: true,
            watchSlidesProgress: true,
            updateOnWindowResize: true,
            grabCursor: false,
            navigation: {
                nextEl: next[0],
                prevEl: prev[0],
            },
            thumbs: {
                swiper: myThumbs
            },
            on: {
                init: function() {

                    var swiper = this;

                    for (var i = 0; i < swiper.slides.length; i++) {
                        $(swiper.slides[i]).find('.bg-img').attr({
                            'data-swiper-parallax': 0.75 * swiper.width
                        })
                    }
                    setTimeout(function(){
                        galleryTop.find( '.swiper-slide:not(:first-child)' ).each(function () {

                            var iframe = $( this ).find('iframe');
                            var vid = $( this ).find('.video-hosted');
                            if ( iframe.length && iframe.hasClass('youtube-video') ) {
                                iframe[0].contentWindow.postMessage('{"event":"command","func":"' + 'pauseVideo' + '","args":""}', '*');
                            }
                            if ( iframe.length && iframe.hasClass('vimeo-video') ) {
                                iframe[0].contentWindow.postMessage('{"method":"pause"}', '*');
                            }
                            if ( vid.length ) {
                                vid.get(0).pause();
                            }
                        });
                    }, 2000);
                    if ( $(window).width() < 1024 ) {
                        setTimeout(function(){
                            galleryTop.find( '.swiper-slide:first-child' ).each(function () {

                                var iframe = $( this ).find('iframe');
                                var vid = $( this ).find('.video-hosted');
                                if ( iframe.length && iframe.hasClass('youtube-video') ) {
                                    iframe[0].contentWindow.postMessage('{"event":"command","func":"' + 'playVideo' + '","args":""}', '*');
                                }
                                if ( iframe.length && iframe.hasClass('vimeo-video') ) {
                                    iframe[0].contentWindow.postMessage('{"method":"play"}', '*');
                                }
                                if ( vid.length ) {
                                    vid.get(0).play();
                                }
                            });
                        }, 2000);
                    }

                },
                transitionStart: function () {
                    if ( $(window).width() < 1024 ) {
                        var item = this.activeIndex;
                        if (item.length ) {
                            mySwiper.slideTo(item);
                        }
                        $Scope.find('.gallery-thumbs .swiper-slide-thumb-active .slide-item-footer').slideDown().addClass('active');
                        $Scope.find('.gallery-thumbs .swiper-slide:not(.swiper-slide-thumb-active ) .slide-item-footer').slideUp().removeClass('active');
                    }
                    if ( $(window).width() > 1024 ) {
                        $Scope.find('.gallery-thumbs .swiper-slide-thumb-active').each( function(){
                            $(this).find('.slide-item-footer').slideDown().addClass('active');
                        });
                        $Scope.find('.gallery-thumbs .swiper-slide:not(.swiper-slide-thumb-active )').each( function(){
                            $(this).find('.slide-item-footer').slideUp().removeClass('active');
                        });
                    }
                },
                slideChange: function () {

                    $( '.swiper-slide:not(.swiper-slide-visible)' ).each(function () {

                        var iframe = $( this ).find('iframe');
                        var vid = $( this ).find('.video-hosted');
                        if ( iframe.length && iframe.hasClass('youtube-video') ) {
                            iframe[0].contentWindow.postMessage('{"event":"command","func":"' + 'pauseVideo' + '","args":""}', '*');
                        }
                        if ( iframe.length && iframe.hasClass('vimeo-video') ) {
                            iframe[0].contentWindow.postMessage('{"method":"pause"}', '*');
                        }
                        if ( vid.length ) {
                            vid.get(0).pause();
                        }

                    });

                    $( '.swiper-slide-visible' ).each(function () {

                        var iframe2 = $( this ).find('iframe');
                        var vid = $( this ).find('.video-hosted');
                        if ( iframe2.length && iframe2.hasClass('youtube-video') ) {
                            iframe2[0].contentWindow.postMessage('{"event":"command","func":"' + 'playVideo' + '","args":""}', '*');
                        }
                        if ( iframe2.length && iframe2.hasClass('vimeo-video') ) {
                            iframe2[0].contentWindow.postMessage('{"method":"play"}', '*');
                        }
                        if ( vid.length ) {
                            vid.get(0).play();
                        }
                    });
                },
                resize: function() {
                    var swiper = this;
                    for (var i = 0; i < swiper.slides.length; i++) {
                        $(swiper.slides[i]).find('.bg-img').attr({
                            'data-swiper-parallax': 0.75 * swiper.width
                        })
                    }
                    swiper.update();
                }
            },
        });
        var hoverItems = function() {
            $Scope.find('.gallery-thumbs .swiper-slide').on('mouseover', function() {
                mySwiper.slideTo($(this).index());
                $(this).find('.slide-item-footer').slideDown().addClass('active');
                $Scope.find('.gallery-thumbs .swiper-slide:not(.swiper-slide-thumb-active) .slide-item-footer').removeClass('active').slideUp();
            });
        }
        var clickItems = function() {
            galleryThumbs.find('.slide-item-footer').slideDown();
        }
        if ( $(window).width() > 1024 ) {
            hoverItems();
        } else {
            clickItems();
            myThumbs.on('activeIndexChange', function () {
                var item = this.realIndex;
                if (item.length ) {
                    mySwiper.slideTo(item);
                }
            });
        }
        $(window).on('resize', function(){
            mySwiper.update();
            myThumbs.update();
            if ( $(window).width() > 1024 ) {
                hoverItems();
            } else {
                clickItems();
                myThumbs.on('activeIndexChange', function () {
                    var item = this.realIndex;
                    if (item.length ) {
                        mySwiper.slideTo(item);
                    }
                });
            }
        });

    }

    jQuery(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/wavo-interactive-link-slider.default', interactiveLinkSlider);
    });

})(jQuery);
