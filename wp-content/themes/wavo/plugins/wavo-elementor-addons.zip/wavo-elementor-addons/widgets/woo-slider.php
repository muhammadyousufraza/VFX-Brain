<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Wavo_Woo_Slider extends Widget_Base {
    use Wavo_Helper;
    public function get_name() {
        return 'wavo-woo-slider';
    }
    public function get_title() {
        return 'WC Slider (N)';
    }
    public function get_icon() {
        return 'eicon-slider-push';
    }
    public function get_categories() {
        return [ 'wavo' ];
    }
    public function get_script_depends() {
        return [ 'wavo-swiper' ];
    }
    // Registering Controls
    protected function register_controls() {

        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'post_query_section',
            [
                'label' => esc_html__( 'Query', 'wavo' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'layout',
            [
                'label' => esc_html__( 'Layout', 'wavo' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'slider' => esc_html__( 'slider', 'wavo' ),
                    'grid' => esc_html__( 'grid', 'wavo' ),
                ],
                'default' => 'slider'
            ]
        );
        $this->add_responsive_control( 'space',
            [
                'label' => esc_html__( 'Space Between Items', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => 30,
                'condition' => ['layout' => 'grid'],
                'selectors' => [
                    '{{WRAPPER}} .woocommerce .products.row' => 'margin:0 calc( -{{SIZE}}px / 2 ) -{{SIZE}}px calc( -{{SIZE}}px / 2 );',
                    '{{WRAPPER}} .woocommerce .products.row .product' => 'padding:0 calc( {{SIZE}}px / 2 );margin-bottom:{{SIZE}}px;'
                ]
            ]
        );
        $this->add_responsive_control( 'column',
            [
                'label' => esc_html__( 'Column', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 12,
                'step' => 1,
                'default' => 4,
                'condition' => ['layout' => 'grid'],
                'selectors' => ['{{WRAPPER}} .woocommerce .products.row .product' => 'flex:0 0 calc(100% / {{SIZE}});max-width:calc(100% / {{SIZE}});']
            ]
        );
        $this->add_control( 'scenario',
            [
                'label' => esc_html__( 'Select Scenario', 'wavo' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__( 'Newest', 'wavo' ),
                    'featured' => esc_html__( 'Featured', 'wavo' ),
                    'on-sale' => esc_html__( 'On Sale', 'wavo' ),
                    'best' => esc_html__( 'Best Selling', 'wavo' ),
                    'custom' => esc_html__( 'Specific Categories', 'wavo' ),
                ],
                'default' => ''
            ]
        );
        $this->add_control( 'post_per_page',
            [
                'label' => esc_html__( 'Posts Per Page', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 1000,
                'default' => 20
            ]
        );
        $this->add_control( 'category_filter_heading',
            [
                'label' => esc_html__( 'Category Filter', 'wavo' ),
                'type' => Controls_Manager::HEADING
            ]
        );
        $this->add_control( 'category_include',
            [
                'label' => esc_html__( 'Category', 'wavo' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->wavo_cpt_taxonomies('product_cat'),
                'description' => 'Select Category(s)',
                'condition' => [ 'scenario' => 'custom' ]
            ]
        );
        $this->add_control( 'category_exclude',
            [
                'label' => esc_html__( 'Exclude Category', 'wavo' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->wavo_cpt_taxonomies('product_cat'),
                'description' => 'Select Category(s) to Exclude',
            ]
        );
        $this->add_control( 'post_filter_heading',
            [
                'label' => esc_html__( 'Post Filter', 'wavo' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control( 'post_include',
            [
                'label' => esc_html__( 'Specific Post(s)', 'wavo' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->get_all_posts_by_type('product'),
                'description' => 'Select Specific Post(s)',
                'condition' => [ 'scenario' => 'custom' ]
            ]
        );
        $this->add_control( 'post_exclude',
            [
                'label' => esc_html__( 'Exclude Post', 'wavo' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->get_all_posts_by_type('product'),
                'description' => 'Select Post(s) to Exclude',
                'separator' => 'after',
            ]
        );
        $this->add_control( 'post_other_heading',
            [
                'label' => esc_html__( 'Other Filter', 'wavo' ),
                'type' => Controls_Manager::HEADING
            ]
        );
        $this->add_control( 'order',
            [
                'label' => esc_html__( 'Select Order', 'wavo' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'ASC' => esc_html__( 'Ascending', 'wavo' ),
                    'DESC' => esc_html__( 'Descending', 'wavo' )
                ],
                'default' => 'DESC'
            ]
        );
        $this->add_control( 'orderby',
            [
                'label' => esc_html__( 'Order By', 'wavo' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'id' => esc_html__( 'Post ID', 'wavo' ),
                    'menu_order' => esc_html__( 'Menu Order', 'wavo' ),
                    'rand' => esc_html__( 'Random', 'wavo' ),
                    'date' => esc_html__( 'Date', 'wavo' ),
                    'title' => esc_html__( 'Title', 'wavo' ),
                ],
                'default' => 'id',
            ]
        );
        $this->add_control( 'pagination',
            [
                'label' => esc_html__( 'Pagination', 'wavo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'separator' => 'before',
                'condition' => ['layout' => 'grid']
            ]
        );
        $this->add_control( 'pag_prev',
            [
                'label' => esc_html__( 'Pagination Prev Text', 'wavo' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'PREV',
                'condition' => ['pagination' => 'yes']
            ]
        );
        $this->add_control( 'pag_next',
            [
                'label' => esc_html__( 'Pagination Next Text', 'wavo' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'NEXT',
                'condition' => ['pagination' => 'yes']
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/
       /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section('slider_options_section',
            [
                'label'=> esc_html__( 'SLIDER OPTIONS', 'wavo' ),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => ['layout' => 'slider']
            ]
        );
        $this->add_control( 'loop',
            [
                'label' => esc_html__( 'Infinite', 'wavo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no'
            ]
        );
        $this->add_control( 'autoplay',
            [
                'label' => esc_html__( 'Autoplay', 'wavo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'
            ]
        );
        $this->add_control( 'centermode',
            [
                'label' => esc_html__( 'Center Mode', 'wavo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no'
            ]
        );
        $this->add_control( 'nav',
            [
                'label' => esc_html__( 'Navigation', 'wavo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no'
            ]
        );
        $this->add_control( 'dots',
            [
                'label' => esc_html__( 'Dots', 'wavo' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'
            ]
        );
        $this->add_control( 'slider_space',
            [
                'label' => esc_html__( 'Space Between Items', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => 30
            ]
        );
        $this->add_control( 'speed',
            [
                'label' => esc_html__( 'Speed', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 100,
                'max' => 10000,
                'step' => 100,
                'default' => 1000
            ]
        );
        $this->add_control( 'mditems',
            [
                'label' => esc_html__( 'Items', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 8,
                'step' => 1,
                'default' => 5
            ]
        );
        $this->add_control( 'smitems',
            [
                'label' => esc_html__( 'Items Tablet', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 3,
                'step' => 1,
                'default' => 3
            ]
        );
        $this->add_control( 'xsitems',
            [
                'label' => esc_html__( 'Items Phone', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 2,
                'step' => 1,
                'default' => 2
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section('product_style_section',
            [
                'label'=> esc_html__( 'PRODUCT STYLE', 'wavo' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'box_style',
            [
                'label' => esc_html__( 'Box Style', 'wavo' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'flat' => esc_html__( 'flat', 'wavo' ),
                    'card' => esc_html__( 'card', 'wavo' ),
                ],
                'default' => 'flat'
            ]
        );
        $this->add_control( 'box_bgcolor',
            [
                'label' => esc_html__( 'Background', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .woocommerce div.products .product.product-flat-style .product-content-wrap,{{WRAPPER}} .woocommerce div.products .product.product-flat-style .product-details-wrap' => 'background-color:{{VALUE}};' ]
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'box_border',
                'label' => esc_html__( 'Box Border', 'wavo' ),
                'selector' => '{{WRAPPER}} .woocommerce div.products .product.product-flat-style .product-content-wrap',
            ]
        );
        $this->add_responsive_control( 'box_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'wavo' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px' ],
                'selectors' => [
                    '{{WRAPPER}} .woocommerce div.products .product.product-flat-style .product-content-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );
        $this->add_responsive_control( 'title_color',
            [
                'label' => esc_html__( 'Title Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .woocommerce div.products .product.product-flat-style .woocommerce-loop-product__title' => 'color:{{VALUE}};' ]
            ]
        );
        $this->add_responsive_control( 'addto_color',
            [
                'label' => esc_html__( 'Add to Cart Title Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .woocommerce div.products .product.product-flat-style .button' => 'color:{{VALUE}};' ]
            ]
        );
        $this->add_responsive_control( 'price_color',
            [
                'label' => esc_html__( 'Price Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .woocommerce div.products .product.product-flat-style .price,{{WRAPPER}} .woocommerce div.products .product.product.product.product-card-style .price del,{{WRAPPER}} .woocommerce div.products .product.product.product.product-card-style .price ins' => 'color:{{VALUE}};' ]
            ]
        );
        $this->add_responsive_control( 'stars_color',
            [
                'label' => esc_html__( 'Star Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .woocommerce .products .product.product-flat-style .star-rating::before' => 'color:{{VALUE}};' ]
            ]
        );
        $this->add_responsive_control( 'stars_rated_color',
            [
                'label' => esc_html__( 'Star Rated Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .woocommerce .products .product.product-flat-style .star-rating >span' => 'color:{{VALUE}};' ]
            ]
        );
        $this->add_responsive_control( 'sale_label_color',
            [
                'label' => esc_html__( 'Sale Label Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .woocommerce .products .product.product-flat-style span.onsale' => 'color:{{VALUE}};' ]
            ]
        );
        $this->add_responsive_control( 'sale_label_bgcolor',
            [
                'label' => esc_html__( 'Sale Label Background Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .woocommerce .products .product.product-flat-style span.onsale' => 'background-color:{{VALUE}};' ]
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/

        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section('navs_style_section',
            [
                'label'=> esc_html__( 'SLIDER NAV STYLE', 'wavo' ),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => ['layout' => 'slider']
            ]
        );
        $this->add_control( 'navs_size',
            [
                'label' => esc_html__( 'Size', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .wavo-products-widget .swiper-button-prev,{{WRAPPER}} .wavo-products-widget .swiper-button-next' => 'width:{{SIZE}}px;height:{{SIZE}}px;' ]
            ]
        );
        $this->add_control( 'navs_icon_size',
            [
                'label' => esc_html__( 'Icon Size', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .wavo-products-widget .swiper-button-prev,{{WRAPPER}} .wavo-products-widget .swiper-button-next' => 'font-size:{{SIZE}}px;' ]
            ]
        );
        $this->add_control( 'navs_color',
            [
                'label' => esc_html__( 'Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .wavo-products-widget .swiper-button-prev i,{{WRAPPER}} .wavo-products-widget .swiper-button-next i' => 'color:{{VALUE}};' ]
            ]
        );
        $this->add_control( 'navs_hvrcolor',
            [
                'label' => esc_html__( 'Hover Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .wavo-products-widget .swiper-button-prev:hover i,{{WRAPPER}} .wavo-products-widget .swiper-button-next:hover i' => 'color:{{VALUE}};' ]
            ]
        );
        $this->add_control( 'navs_bgcolor',
            [
                'label' => esc_html__( 'Background Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .wavo-products-widget .swiper-button-prev,{{WRAPPER}} .wavo-products-widget .swiper-button-next' => 'background-color:{{VALUE}};' ]
            ]
        );
        $this->add_control( 'navs_hvrbgcolor',
            [
                'label' => esc_html__( 'Hover Background Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .wavo-products-widget .swiper-button-prev:hover,{{WRAPPER}} .wavo-products-widget .swiper-button-next:hover' => 'background-color:{{VALUE}};' ]
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section('dots_style_section',
            [
                'label'=> esc_html__( 'SLIDER DOTS STYLE', 'wavo' ),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => ['layout' => 'slider']
            ]
        );
        $this->add_control( 'dots_top_offset',
            [
                'label' => esc_html__( 'Top Offset', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .wavo-products-widget .swiper-pagination-bullets' => 'margin-top:{{SIZE}}px;' ]
            ]
        );
        $this->add_responsive_control( 'dots_alignment',
            [
                'label' => esc_html__( 'Alignment', 'wavo' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'wavo' ),
                        'icon' => 'eicon-h-align-left'
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'wavo' ),
                        'icon' => 'eicon-h-align-center'
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'wavo' ),
                        'icon' => 'eicon-h-align-right'
                    ]
                ],
                'toggle' => true,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .wavo-products-widget .swiper-pagination-bullets' => 'text-align:{{VALUE}};' ]
            ]
        );
        $this->add_control( 'dots_size',
            [
                'label' => esc_html__( 'Size', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .swiper-pagination-bullets .swiper-pagination-bullet' => 'width:{{SIZE}}px;height:{{SIZE}}px;' ]
            ]
        );
        $this->add_control( 'dots_space',
            [
                'label' => esc_html__( 'Space', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .swiper-pagination-bullets .swiper-pagination-bullet + .swiper-pagination-bullet' => 'margin: 0;margin-left: {{SIZE}}px;']
            ]
        );
        $this->start_controls_tabs( 'dots_nav_tabs');
        $this->start_controls_tab( 'dots_normal_tab',
            [ 'label' => esc_html__( 'Normal', 'wavo' ) ]
        );
        $this->add_control( 'dots_bgcolor',
            [
                'label' => esc_html__( 'Background', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .swiper-pagination-bullets .swiper-pagination-bullet' => 'background-color:{{VALUE}};' ]
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'dots_border',
                'label' => esc_html__( 'Border', 'wavo' ),
                'selector' => '{{WRAPPER}} .swiper-pagination-bullets .swiper-pagination-bullet',
            ]
        );
        $this->add_responsive_control( 'dots_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'wavo' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px' ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullets .swiper-pagination-bullet' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab( 'dots_hover_tab',
            [ 'label' => esc_html__( 'Active', 'wavo' ) ]
        );
        $this->add_control( 'dots_hvrbgcolor',
            [
                'label' => esc_html__( 'Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'background-color:{{VALUE}};' ]
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'dots_hvrborder',
                'label' => esc_html__( 'Border', 'wavo' ),
                'selector' => '{{WRAPPER}} .swiper-pagination-bullet.swiper-pagination-bullet-active'
            ]
        );
        $this->add_responsive_control( 'dots_hvrborder_radius',
            [
                'label' => esc_html__( 'Border Radius', 'wavo' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px' ],
                'selectors' => ['{{WRAPPER}} .swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'pagination_style_section',
            [
                'label'=> esc_html__( 'PAGINATION STYLE', 'wavo' ),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => ['pagination' => 'yes']
            ]
        );
        $this->add_control( 'pagination_top_space',
            [
                'label' => esc_html__( 'Space', 'wavo' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 200,
                'step' => 1,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .wc-product-pagination' => 'margin: 0;margin-top: {{SIZE}}px;']
            ]
        );
        $this->wavo_style_typo( 'pagination_typo','{{WRAPPER}} .wc-product-pagination .page-numbers' );
        $this->add_control( 'pagination_bg',
            [
                'label' => esc_html__( 'Background', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wc-product-pagination .page-numbers' => 'background-color: {{VALUE}};' ]
            ]
        );
        $this->add_control( 'pagination_hvrbg',
            [
                'label' => esc_html__( 'Hover/Active Background', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wc-product-pagination .page-numbers.current, {{WRAPPER}} .wc-product-pagination .page-numbers:hover' => 'background-color: {{VALUE}};' ]
            ]
        );
        $this->add_control( 'pagination_color',
            [
                'label' => esc_html__( 'Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wc-product-pagination .page-numbers' => 'color: {{VALUE}};' ]
            ]
        );
        $this->add_control( 'pagination_hvrcolor',
            [
                'label' => esc_html__( 'Hover Color', 'wavo' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .wc-product-pagination .page-numbers:hover' => 'color: {{VALUE}};' ]
            ]
        );
        $this->add_responsive_control( 'pag_alignment',
            [
                'label' => esc_html__( 'Alignment', 'wavo' ),
                'type' => Controls_Manager::CHOOSE,
                'selectors' => ['{{WRAPPER}} .wc-product-pagination' => 'justify-content: {{VALUE}}!important;'],
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Left', 'wavo' ),
                        'icon' => 'eicon-h-align-left'
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'wavo' ),
                        'icon' => 'eicon-h-align-center'
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'Right', 'wavo' ),
                        'icon' => 'eicon-h-align-right'
                    ]
                ],
                'toggle' => true,
                'default' => 'center',
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/
    }

    public function product_box_style() {
        $settings = $this->get_settings_for_display();

        echo '<div class="product-content-wrap">';

            echo '<div class="product-image-wrap">';
                echo woocommerce_template_loop_product_link_open();
                do_action( 'woocommerce_before_shop_loop_item_title' );
                echo woocommerce_template_loop_product_link_close();
                echo woocommerce_template_loop_rating();
            echo '</div>';

            echo '<div class="product-details-wrap">';
                echo woocommerce_template_loop_product_link_open();
                echo '<div class="woocommerce-loop-product__title">'.get_the_title().'</div>';
                echo woocommerce_template_loop_price();
                echo woocommerce_template_loop_product_link_close();
                do_action( 'woocommerce_after_shop_loop_item' );
            echo '</div>';

        echo '</div>';
    }
    protected function render() {
        global $wp_query;
        $settings = $this->get_settings_for_display();
        $id = $this->get_id();
        if ( ! class_exists( 'WooCommerce' ) ) {
            return;
        }

        $args = array(
            'post_type'      => 'product',
            'posts_per_page' => $settings['post_per_page'],
            'post__in'       => $settings['post_include'],
            'post__not_in'   => $settings['post_exclude'],
            'order'          => $settings['order']
        );

        if ( $settings['pagination'] == 'yes' ) {
            $paged = get_query_var( 'paged') ? get_query_var('paged') : 1;
            $args['paged'] = $paged;
        }

        if ( 'featured' == $settings['scenario'] ) {
           $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_visibility',
                    'field' => 'name',
                    'terms' => 'featured'
                )
            );

        } elseif('on-sale' == $settings['scenario']) {

            $args['meta_query'] = array(
                'relation' => 'OR',
                array( // Simple products type
                    'key' => '_sale_price',
                    'value' => 0,
                    'compare' => '>',
                    'type' => 'numeric'
                ),
                array( // Variable products type
                    'key' => '_min_variation_sale_price',
                    'value' => 0,
                    'compare' => '>',
                    'type' => 'numeric'
                )
            );

        } elseif('best' == $settings['scenario']) {

            $args['orderby'] = 'meta_value_num';
            $args['meta_key'] = 'total_sales';

        } else {

            $args['orderby'] = $settings['orderby'];

        }

        if ( $settings['category_include'] ) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'id',
                    'terms' => $settings['category_include'],
                    'operator' => 'IN'
                )
            );
        }
        if ( $settings['category_exclude'] ) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'id',
                    'terms' => $settings['category_exclude'],
                    'operator' => 'NOT IN'
                )
            );
        }

        $editmode = \Elementor\Plugin::$instance->editor->is_edit_mode() ? '-'.$id: '';

        $slider_options = json_encode( array(
                "slidesPerView" => 1,
                "loop"          => 'yes' == $settings['loop'] ? true: false,
                "autoHeight"    => false,
                "autoplay"      => 'yes' == $settings['autoplay'] ? true: false,
                "centeredSlides"=> 'yes' == $settings['centermode'] ? true: false,
                "speed"         => $settings['speed'],
                "spaceBetween"  => $settings['slider_space'] ? $settings['slider_space'] : 30,
                "direction"     => "horizontal",
                "navigation" => [
                    "nextEl" => ".wavo-products-widget .slide-next-$id",
                    "prevEl" => ".wavo-products-widget .slide-prev-$id"
                ],
                "pagination" => [
                    "el" => ".wavo-products-widget .wavo-pagination-$id",
                    "type" => "bullets",
                    "clickable" => true
                ],
                "breakpoints" => [
                    "0" => [
                        "slidesPerView" => $settings['xsitems'],
                        "slidesPerGroup" => $settings['xsitems']
                    ],
                    "768" => [
                        "slidesPerView" => $settings['smitems'],
                        "slidesPerGroup" => $settings['smitems']
                    ],
                    "1024" => [
                        "slidesPerView" => $settings['mditems'],
                        "slidesPerGroup" => $settings['mditems']
                    ]
                ]
            )
        );

        $the_query = new \WP_Query( $args );
        if ( $the_query->have_posts() ) {
            $box_style = 'card' == $settings['box_style'] ? ' product-card-style' : '';
            $type      = 'grid' == $settings['layout'] ? ' wavo-products-grid"' : ' swiper-container wavo-swiper-slider'.$editmode.'" data-swiper-options=\''.$slider_options.'\'';
            $rowtype   = 'grid' == $settings['layout'] ? 'row products' : 'swiper-wrapper products';
            $itemtype  = 'grid' == $settings['layout'] ? ' col-12 col-sm-2 col-lg-4' : ' swiper-slide';
            echo '<div class="wavo-products-widget woocommerce'.$type.'>';
                echo '<div class="'.$rowtype.'">';
                    while ( $the_query->have_posts() ) {
                        $the_query->the_post();
                        $product = new \WC_Product(get_the_ID());

                        if ( $product->get_catalog_visibility() != 'hidden' ) {
                            echo '<div class="product product-flat-style'.$box_style.$itemtype.'">';
                                echo $this->product_box_style();
                            echo '</div>';
                        }
                    }
                    wp_reset_postdata();
                echo '</div>';
                if ( 'yes' == $settings['dots'] && 'slider' == $settings['layout'] ) {
                    echo '<div class="swiper-pagination wavo-pagination-'.$id.'"></div>';
                }
                if ( 'yes' == $settings['nav'] && 'slider' == $settings['layout'] ) {
                    echo '<div class="swiper-button-next slide-prev-'.$id.'"><i class="ion-ios-arrow-right"></i></div>';
                    echo '<div class="swiper-button-prev slide-next-'.$id.'"><i class="ion-ios-arrow-left"></i></div>';
                }
            echo '</div>';
            if ( $settings['pagination'] == 'yes' ) {

                echo '<div class="wc-product-pagination nt-pagination d-flex justify-content-center align-items-center">';
                    $total_pages = $the_query->max_num_pages;
                    $big = 999999999;
                    if ( $total_pages > 1 ) {
                        echo paginate_links(array(
                            'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                            'format'    => '?paged=%#%',
                            'current'   => max(1, $paged),
                            'total'     => $total_pages,
                            'type'      => '',
                            'prev_text' => $settings['pag_prev'] ? esc_html($settings['pag_prev']) : 'PREV',
                            'next_text' => $settings['pag_next'] ? esc_html($settings['pag_next']) : 'NEXT',
                            'before_page_number' => '<div class="nt-pagination-item">',
                            'after_page_number' => '</div>'
                        ));
                    }
                echo '</div>';
            }
        }

        if ( \Elementor\Plugin::$instance->editor->is_edit_mode() && 'slider' == $settings['layout'] ) { ?>
            <script>
            jQuery( document ).ready( function($) {
                $('.wavo-swiper-slider-<?php echo $id ?>').each(function () {
                    const options  = JSON.parse(this.dataset.swiperOptions);
                    const mySlider = new SwiperNT(this, $(this).data('swiper-options'));

                    $(this).hover(function() {
                        if ( options.autoplay == true ) {
                            mySlider.autoplay.stop();
                        }
                    }, function() {
                        if ( options.autoplay == true ) {
                            mySlider.autoplay.start();
                        }
                    });

                });
            });
            </script>
            <?php
        }
    }
}
