<?php
/*
* page settings
*/
add_action( 'elementor/documents/register_controls', 'wavo_add_theme_skin_to_page_settings' );

function wavo_add_theme_skin_to_page_settings( $document )
{
    if ( ! $document instanceof \Elementor\Core\DocumentTypes\PageBase || ! $document::get_property( 'has_elements' ) ) {
        return;
    }
    $document->start_controls_section( 'page_settings_controls_section',
        [
            'label' => esc_html__( 'PAGE SETTINGS', 'wavo' ),
            'tab' => \Elementor\Controls_Manager::TAB_SETTINGS
        ]
    );
    $document->add_control( 'wavo_elementor_hide_page_header',
        [
            'label' => esc_html__( 'Hide Page Header', 'wavo' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'default' => 'no',
            'conditions' => [
                'relation' => 'or',
                'terms' => [
                    [ 'name' => 'template','operator' => '==','value' => 'wavo-elementor-page.php' ],
                    [ 'name' => 'template','operator' => '==','value' => 'locomotive-page.php' ]
                ]
            ]
        ]
    );
    $args = [
        'post_type'      => 'elementor_library',
        'posts_per_page' => -1,
        'tax_query'      => [
            'taxonomy' => 'elementor_library_type',
            'field'    => 'slug',
            'terms'    => 'section'
        ]
    ];
    $page_templates = get_posts($args);
    $options = array();
    if (!empty($page_templates) && !is_wp_error($page_templates)) {
        foreach ($page_templates as $post) {
            $options[$post->ID] = $post->post_title;
        }
    }
    $document->add_control( 'wavo_elementor_page_header_template',
        [
            'label' => esc_html__( 'Select Header Template', 'venam' ),
            'type' => \Elementor\Controls_Manager::SELECT2,
            'default' => '',
            'multiple' => false,
            'options' => $options,
            'condition' => [ 'wavo_elementor_hide_page_header!' => 'yes' ]
        ]
    );
    $document->add_control( 'wavo_elementor_page_skin',
        [
            'label' => esc_html__( 'Page Skin Type', 'wavo' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => '',
            'options' => [
                '' => esc_html__( 'Slect a type', 'wavo' ),
                'dark' => esc_html__( 'Dark', 'wavo' ),
                'light' => esc_html__( 'Light', 'wavo' ),
                'custom-skin-color' => esc_html__( 'Custom', 'wavo' ),
            ],
            'separator' => 'before',
            'condition' => [ 'template' => 'wavo-elementor-page.php' ]
        ]
    );
    $document->add_control( 'wavo_page_custom_skin',
        [
            'label' => esc_html__( 'Color', 'wavo' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '.custom-skin-color, .custom-skin-color .elementor-top-section' => 'background-color:{{VALUE}};',
                '.skin-overlay-color .elementor-background-overlay' => 'background-color:{{VALUE}};opacity:0.96;'
            ],
            'conditions' => [
                'relation' => 'and',
                'terms' => [
                    [ 'name' => 'template','operator' => '==','value' => 'wavo-elementor-page.php' ],
                    [ 'name' => 'wavo_elementor_page_skin','operator' => '==','value' => 'custom-skin-color' ]
                ]
            ]
        ]
    );
    $document->add_control( 'wavo_page_heading_color',
        [
            'label' => esc_html__( 'Section Heading Color', 'wavo' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '.elementor-widget-heading' => 'color:{{VALUE}};',
                '.wavo-headig-line .elementor-heading-title::after' => 'background-color:{{VALUE}};',
                '.clients .brands' => 'border-right-color:{{VALUE}};',
            ],
            'conditions' => [
                'relation' => 'and',
                'terms' => [
                    [ 'name' => 'template','operator' => '==','value' => 'wavo-elementor-page.php' ],
                    [ 'name' => 'wavo_elementor_page_skin','operator' => '==','value' => 'custom-skin-color' ]
                ]
            ]
        ]
    );
    $document->add_control( 'wavo_elementor_page_nav_skin',
        [
            'label' => esc_html__( 'Page Navigation Type', 'wavo' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => '',
            'options' => [
                '' => esc_html__( 'Slect a type', 'wavo' ),
                'dark' => esc_html__( 'Dark', 'wavo' ),
                'light' => esc_html__( 'Light', 'wavo' ),
            ],
            'separator' => 'before',
            'condition' => [ 'template' => 'wavo-elementor-page.php' ]
        ]
    );
    $document->add_control( 'wavo_elementor_hide_page_footer',
        [
            'label' => esc_html__( 'Hide Footer', 'wavo' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default' => 'no',
            'separator' => 'before',
            'condition' => [ 'template' => 'wavo-elementor-page.php' ]
        ]
    );
    $document->end_controls_section();
    $document->start_controls_section( 'header_custom_css_controls_section',
        [
            'label' => esc_html__( 'WAVO Page Custom CSS', 'wavo' ),
            'tab' => \Elementor\Controls_Manager::TAB_SETTINGS,
        ]
    );
    $document->add_control( 'wavo_page_custom_css',
        [
            'label' => esc_html__( 'Custom CSS', 'wavo' ),
            'type' => \Elementor\Controls_Manager::CODE,
            'language' => 'css',
            'rows' => 20
        ]
    );
    $document->end_controls_section();
}
