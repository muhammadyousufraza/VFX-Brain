<?php
/**
* Taxonomy: Wavo Brands.
*/
if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.
if ( ! class_exists( 'Wavo_Popup_Builder' ) ) {
    class Wavo_Popup_Builder {
        private static $instance = null;
        public static function get_instance() {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self;
            }
            return self::$instance;
        }
        public function __construct() {
            if ( ! get_option( 'disable_wavo_popups_builder' ) == 1 ) {
                add_action( 'init', array( $this, 'wavo_register_popups' ) );

                $cpt_support = get_option( 'elementor_cpt_support' );
                if ( is_array( $cpt_support ) && ! in_array( 'wavo_popups', $cpt_support ) ) {
                    $cpt_support[] = 'wavo_popups';
                    update_option( 'elementor_cpt_support', $cpt_support );
                }
                // Add the custom columns to the book post type:
                add_filter( 'manage_wavo_popups_posts_columns', array( $this, 'set_custom_edit_wavo_popups_columns' ) );
                // Add the data to the custom columns for the book post type:
                add_action( 'manage_wavo_popups_posts_custom_column' , array( $this, 'custom_wavo_popups_column' ), 10, 2 );
            }
        }
        function wavo_register_popups() {

            /**
            * Post Type: Wavo Popups.
            */

            $labels = [
                "name" => __( "Popups Builder", "wavo" ),
                "singular_name" => __( "Popup Builder", "wavo" ),
                "menu_name" => __( "Popups Builder", "wavo" ),
                "all_items" => __( "Popups Builder", "wavo" ),
                "add_new" => __( "Add Popup", "wavo" ),
                "add_new_item" => __( "Add new Popup", "wavo" ),
                "edit_item" => __( "Edit Popup", "wavo" ),
                "new_item" => __( "New Popup", "wavo" ),
                "view_item" => __( "View Popup", "wavo" ),
                "view_items" => __( "View Popups", "wavo" ),
                "search_items" => __( "Search Popups", "wavo" ),
                "not_found" => __( "No Popups found", "wavo" ),
                "not_found_in_trash" => __( "No Popups found in trash", "wavo" ),
                "archives" => __( "Popup archives", "wavo" )
            ];

            $args = [
                "label" => __( "Wavo Popups", "wavo" ),
                "labels" => $labels,
                "description" => "",
                "public" => true,
                "publicly_queryable" => true,
                "show_ui" => true,
                "show_in_rest" => true,
                "rest_base" => "",
                "rest_controller_class" => "WP_REST_Posts_Controller",
                "has_archive" => false,
                "show_in_menu" => "ninetheme_theme_manage",
                "show_in_nav_menus" => true,
                "delete_with_user" => false,
                "exclude_from_search" => false,
                "capability_type" => "post",
                "map_meta_cap" => true,
                "hierarchical" => false,
                "rewrite" => [ "slug" => "wavo_popups", "with_front" => true ],
                "query_var" => true,
                "supports" => [ "title", "editor" ],
                "show_in_graphql" => false
            ];

            register_post_type( "wavo_popups", $args );
        }

        function set_custom_edit_wavo_popups_columns($columns) {
            $columns[ 'shortcode' ] = __( "Popups ID", "wavo" );

            return $columns;
        }

        function custom_wavo_popups_column( $column, $post_id ) {

            if ( 'shortcode' === $column ) {

                /** %s = shortcode tag, %d = post_id */
                $shortcode = esc_attr(
                    sprintf(
                        '#%s%d',
                        'wavo-popup-',
                        $post_id
                    )
                );
                printf(
                    '<input class="wavo-popup-input widefat" type="text" readonly onfocus="this.select()" value="%s" />',
                    $shortcode
                );
            }
        }
    }
    Wavo_Popup_Builder::get_instance();
}
